import { LetrasPipe } from './letras.pipe';

describe('LetrasPipe', () => {
  it('create an instance', () => {
    const pipe = new LetrasPipe();
    expect(pipe).toBeTruthy();
  });
});

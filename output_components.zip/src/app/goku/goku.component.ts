import { Component } from '@angular/core';

@Component({
  selector: 'app-goku',
  templateUrl: './goku.component.html',
  styleUrls: ['./goku.component.css']
})
export class GokuComponent {
  genkidama: boolean = false;
  genkidamaImg: string = "";
  kamehamehaGoku: string = "KAME HAME HA!"
  
  constructor() { }

  genkidamaLista(confirmation: boolean){
    this.genkidama = confirmation;
    console.log(this.genkidama);

    //hacer genkidama si es true
    if(this.genkidama){
      this.genkidamaImg = 'https://www.egames.news/__export/1651342757840/sites/debate/img/2022/04/30/por_qux_la_genkidama_de_gokx_solo_funcionx_una_vez_en_dragon_ball.jpg_242310155.jpg'
    }
  }

}

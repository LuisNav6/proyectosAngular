import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-gohan',
  templateUrl: './gohan.component.html',
  styleUrls: ['./gohan.component.css']
})
export class GohanComponent implements OnInit{
  @Input() kamehamehaGohan: string = "";
  @Output() energiaGohan = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }

  genkidamaAlerta(msg: boolean){
    this.energiaGohan.emit(msg)
    console.log(msg);
  }
}

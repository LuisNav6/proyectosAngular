export class usuario{
    nombre: string="";
    apellido: string="";
    telefono: string="";
    correo: string="";
    image: string="";
    }
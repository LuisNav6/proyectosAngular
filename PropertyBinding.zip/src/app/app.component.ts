import { Component } from '@angular/core';
import { usuario } from '../modelo/usuario';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PropertyBinding';
  
  user1: usuario = {
    nombre: "Luis",
    apellido: "Enriquez",
    telefono: "449-108-9892",
    correo: "luisEnr@gmail.com",
    image: "../assets/imagenes/mono1.jpeg"
    };
  user2: usuario = {
    nombre: "Ernesto",
    apellido: "Manriquez",
    telefono: "322-178-4567",
    correo: "EnreMan@gmail.com",
    image: "../assets/imagenes/mono2.jpeg"
    };
  user3: usuario = {
    nombre: "Juana",
    apellido: "Marin",
    telefono: "464-123-4567",
    correo: "Juani1M@gmail.com",
    image: "../assets/imagenes/mona.jpeg"
    };
}

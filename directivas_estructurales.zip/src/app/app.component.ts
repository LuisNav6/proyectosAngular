import { Component,NgModule, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'proyecto240323';
  nombre: string="";
  promedio: number=0;
  estudiantes: Datos[]=[
    {nombre: 'Luis Navarrete', promedio: 10 },
    {nombre: 'Ernesto Ramirez',promedio: 10 },
    {nombre: 'Itzel Vazquez',promedio: 8 },
    {nombre: 'Armando Escareño',promedio: 8 },
    {nombre: 'Jose Jimenez',promedio: 9 }
  ];

  constructor(){
    console.log('Soy el constructor, listo atributos inicializados');
    console.log(this.estudiantes.map(estudiante => estudiante.nombre));
  }

  ngOnInit(){
    console.log('Soy el ngOnInit en este momento el componente ha cargado ');
    //foco en la captura del nombre
    document.getElementById('exampleInput1')?.focus();
  }

  agregarDatos():void{
    //objeto local
    let aux: Datos = {
      nombre: this.nombre,
      promedio: this.promedio,
    };

    this.estudiantes.push(aux);
    this.borrarDatos();
    document.getElementById('exampleInput1')?.focus();
    console.log(this.estudiantes.map(estudiante => estudiante.nombre));
    }

    borrarDatos():void{
      this.nombre = '';
      this.promedio = 0;
    }

    eliminarRegistro(nombre: any, evento: any): void{
      //localiza el nombre y devuelve el indice del arreglo donde esta
      let indice = this.estudiantes.findIndex((p) => p.nombre === nombre);
      this.estudiantes.splice(indice,1);

      alert('Estudiante' + nombre + ' eliminado. \nEvento capturado: '+ evento.type + '.'   );
    }
}

interface Datos{
  nombre: string;
  promedio: number;
}
